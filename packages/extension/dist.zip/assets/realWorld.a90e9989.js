let e=!1;function i(){e||(e=!0,postMessage("__SolidOnPage__","*"))}window.Solid$$==!0?i():Object.defineProperty(window,"Solid$$",{set(t){t===!0&&i()}});
